import numpy as np
from sklearn.model_selection import train_test_split
from sklearn.linear_model import LogisticRegression
import sklearn.metrics
from matplotlib import pyplot as plt
import time
import itertools
import math


#def cross_entropy(t, y, m):
#    return - (np.sum(np.multiply(t, np.log(y)) + np.multiply((1-t), np.log(1-y))))/m

def computeKernel(X, d):
    m = X.shape[0]
    K = np.zeros(shape = (m,m))
    for i in range(m):
        for j in range(m):
            K[i,j] = ((np.dot(X[i,:], X[j,:])) + 1)**d
    return K

def kernelizedLogisticRegression(K, y):

    factorK = np.linalg.cholesky(K).transpose()
    Xtrain, Xtest, ytrain, ytest = train_test_split(factorK, y, test_size=0.2, random_state=int(time.time() * 1000.0))

    classifier = LogisticRegression(penalty='l2', dual = False, max_iter= 100000)
    classifier.fit(Xtrain, ytrain)

    y_pred = classifier.predict_proba(Xtrain)
    print "Training :"
    print "Cross Entopy Error : ", sklearn.metrics.log_loss(ytrain,y_pred)
    y_pred = classifier.predict(Xtrain)
    print "Accuracy : ", sklearn.metrics.accuracy_score(ytrain, y_pred)

    y_pred = classifier.predict_proba(Xtest)
    print "Test :"
    print "Cross Entopy Error : ", sklearn.metrics.log_loss(ytest, y_pred)
    y_pred = classifier.predict(Xtest)
    print "Accuracy : ", sklearn.metrics.accuracy_score(ytest, y_pred)


def main():
    #Read dataset
    data = np.loadtxt('hw1x.dat')
    y = np.loadtxt('hw1y.dat')
    [m, n] = data.shape


    #normalize data
    for i in range(n):
        data[:,i] = (data[:,i] - np.amin(data[:,i])) / (np.amax(data[:,i]) - np.amin(data[:,i]))

    #update dataset
    X = np.column_stack([np.ones(data.shape[0]), data])


    #Train test split
    Xtrain, Xtest, ytrain, ytest = train_test_split(X, y, test_size=0.2, random_state=int(time.time()*1000.0))

    #define regularization parameter
    inv_lambdas = np.array([10**10, 10, 1, 0.1, 0.01, 0.001])

    cross_entropy_train = []
    cross_entropy_test = []
    parameters = []
    train_accuracy = []
    test_accuracy = []
    #parameters = np.array([])

    #run logistic regression
    for inv_lambda in inv_lambdas:
        classifier = LogisticRegression(penalty='l2', C=inv_lambda, max_iter= 100000)
        classifier.fit(Xtrain, ytrain)


        #y_pred = classifier.predict(Xtrain)
        #Training Cross-entropy
        y_pred = classifier.predict_proba(Xtrain)
        #cross_entropy_train.append(cross_entropy(ytrain, y_pred[:,1],ytrain.shape[0]))
        cross_entropy_train.append(sklearn.metrics.log_loss(ytrain, y_pred))

        y_pred = classifier.predict(Xtrain)
        train_accuracy.append(sklearn.metrics.accuracy_score(ytrain, y_pred))


        #Testing Cross-entropy
        y_pred = classifier.predict_proba(Xtest)
        #cross_entropy_test.append(cross_entropy(ytest, y_pred[:,1],ytest.shape[0]))
        cross_entropy_test.append((sklearn.metrics.log_loss(ytest, y_pred)))

        y_pred = classifier.predict(Xtest)
        test_accuracy.append(sklearn.metrics.accuracy_score(ytest, y_pred))

        parameters.append(classifier.coef_)


    #Fig 1 : Plot average cross-entropy
    fig = plt.figure()
    fig.suptitle('(d) Fig 1 : Average Cross-Entropy as function of Regularization Parameter', fontsize=14,
                 fontweight='bold')

    ax = fig.add_subplot(111)
    ax.set_xlabel('$Log_{10}(\lambda)$')
    ax.set_ylabel('cross-entropy loss')
    plt.plot(np.log10(1./inv_lambdas), cross_entropy_train, color='blue', label = 'train')
    plt.plot(np.log10(1. / inv_lambdas), cross_entropy_test, color='red', label = 'test')
    #plt.xscale('log')
    handles, labels = ax.get_legend_handles_labels()
    ax.legend(handles, labels)
    plt.show()

    #Fig 2 : L2 norm of weight vector you obtain
    l2_norm = []
    for i in range(len(parameters)):
        l2_norm.append(np.linalg.norm(parameters[i], ord = 2))

    fig = plt.figure()
    fig.suptitle('(d) Fig 2 : L2 norm of weights as function of Regularization Parameter', fontsize=14, fontweight='bold')

    ax = fig.add_subplot(111)
    ax.set_xlabel('$Log_{10}(\lambda)$')
    ax.set_ylabel('L2 norm of weights')
    plt.plot(np.log(1. / inv_lambdas), l2_norm, color='blue')
    #handles, labels = ax.get_legend_handles_labels()
    #ax.legend(handles, labels)
    plt.show()


    #Fig 3 : Actual values of weights obtained (one curve per weight)
    fig = plt.figure()
    fig.suptitle('(d) Fig 3 : Actual values of weights obtained', fontsize=14, fontweight='bold')
    ax = fig.add_subplot(111)
    ax.set_xlabel('$Log_{10}(\lambda)$')
    ax.set_ylabel('weight')
    parameters = np.asarray(parameters)
    for i in range(parameters.shape[2]):
        plt.plot(parameters[:,0,i])
    plt.show()

    #Fig 4 : Accuracy on training and test set
    fig = plt.figure()
    fig.suptitle('(d) Fig 4 : Accuracy as function of Regularization Parameter', fontsize=14, fontweight='bold')

    ax = fig.add_subplot(111)
    ax.set_xlabel('$Log_{10}(\lambda)$')
    ax.set_ylabel('Accuracy')
    plt.plot(np.log10(1./inv_lambdas), train_accuracy, color='blue', label = 'train')
    plt.plot(np.log10(1. / inv_lambdas), test_accuracy, color='red', label = 'test')
    handles, labels = ax.get_legend_handles_labels()
    ax.legend(handles, labels)
    plt.show()

    #Question 1, section e

    train_error = []
    test_error = []
    l2 = []
    #basis_X = np.empty(shape=(X.shape[0], 314))
    inv_lambdas = np.array([10 ** 10, 10, 1, 0.1, 0.01, 0.001, 0.0001])


    #LargeX = X
    LargeX = np.ones(shape=(X.shape[0],1))
    sigma = [0.1, 0.5, 1, 5, 10]
    for sgm in sigma:
        fmt_X = np.ones(shape=(X.shape[0],1))
        l2_norm_sigma = []
        #print sgm
        #print fmt_X.shape
        for meu,i in itertools.product(range(-10,10,4), range(1,X.shape[1])):
            #print meu, i
            new_col = np.exp(-(X[:,i] - meu)**2/(2 * sgm**2)).reshape(X.shape[0],1)
            fmt_X = np.hstack((fmt_X, new_col))
            LargeX = np.hstack((LargeX, new_col))

            #basis_X = np.vstack((basis_X, fmt_X))
            #print basis_X.shape

        Xtrain, Xtest, ytrain, ytest = train_test_split(fmt_X, y, test_size=0.2, random_state=int(time.time()*1000.0))

        #print fmt_X.shape


        classifier = LogisticRegression(max_iter = 100000)
        classifier.fit(Xtrain, ytrain)

        #y_pred = classifier.predict(Xtrain)
        #train_error.append(sklearn.metrics.mean_squared_error(ytrain, y_pred))

        y_pred = classifier.predict_proba(Xtrain)
        train_error.append(sklearn.metrics.log_loss(ytrain, y_pred))

        #y_pred = classifier.predict(Xtest)
        #test_error.append(sklearn.metrics.mean_squared_error(ytest, y_pred))

        y_pred = classifier.predict_proba(Xtest)
        test_error.append(sklearn.metrics.log_loss(ytest, y_pred))

        for inv_lambda in inv_lambdas:
            clf = LogisticRegression(penalty='l2', C=inv_lambda, max_iter=100000)
            clf.fit(Xtrain, ytrain)

            #l2_norm_sigma = []
            l2_norm_sigma.append(np.linalg.norm(clf.coef_, ord = 2))
        #print l2_norm_sigma
        l2.append(l2_norm_sigma)




            #l2_norm_sigma.append(np.linalg.norm(classifier.coef_, ord= 2))

    #Fig (f) : Error on training and test set
    fig = plt.figure()
    fig.suptitle('Q1. (f) Error as function of $Sigma$', fontsize=14, fontweight='bold')

    ax = fig.add_subplot(111)
    ax.set_xlabel('sigma')
    ax.set_ylabel('Error')
    plt.plot(sigma, train_error, color='blue', label = 'train')
    plt.plot(sigma, test_error, color='red', label = 'test')
    handles, labels = ax.get_legend_handles_labels()
    ax.legend(handles, labels)
    plt.show()

    print LargeX.shape
    inv_lambdas = np.array([10**10, 10, 1, 0.1, 0.01, 0.001, 0.0001])

    Xtrain, Xtest, ytrain, ytest = train_test_split(LargeX, y, test_size=0.2, random_state=int(time.time()*1000.0))

    cross_entropy_train = []
    cross_entropy_test = []
    parameters = []
    train_accuracy = []
    test_accuracy = []

    for inv_lambda in inv_lambdas:
        classifier = LogisticRegression(penalty='l2', C=inv_lambda, max_iter= 100000)
        classifier.fit(Xtrain, ytrain)


        #Training Cross-entropy
        y_pred = classifier.predict_proba(Xtrain)
        #cross_entropy_train.append(cross_entropy(ytrain, y_pred[:,1],ytrain.shape[0]))
        cross_entropy_train.append(sklearn.metrics.log_loss(ytrain, y_pred))

        y_pred = classifier.predict(Xtrain)
        train_accuracy.append(sklearn.metrics.accuracy_score(ytrain, y_pred))


        #Testing Cross-entropy
        y_pred = classifier.predict_proba(Xtest)
        #cross_entropy_test.append(cross_entropy(ytest, y_pred[:,1],ytest.shape[0]))
        cross_entropy_test.append(sklearn.metrics.log_loss(ytest, y_pred))

        y_pred = classifier.predict(Xtest)
        test_accuracy.append(sklearn.metrics.accuracy_score(ytest, y_pred))

        parameters.append(classifier.coef_)


    #Fig 1 : Plot average cross-entropy
    fig = plt.figure()
    fig.suptitle('(g) Fig 1 : Average Cross-Entropy as function of $\lambda$', fontsize=14, fontweight='bold')

    ax = fig.add_subplot(111)
    ax.set_xlabel('lambda')
    ax.set_ylabel('cross-entropy loss')
    plt.plot(np.log10(1./inv_lambdas), cross_entropy_train, color='blue', label = 'train')
    plt.plot(np.log10(1. / inv_lambdas), cross_entropy_test, color='red', label = 'test')
    #plt.xscale('log')
    handles, labels = ax.get_legend_handles_labels()
    ax.legend(handles, labels)
    plt.show()

    #Fig 2 : L2 norm of weight vector you obtain
    l2_norm = []
    for i in range(len(parameters)):
        l2_norm.append(np.linalg.norm(parameters[i], ord = 2))

    fig = plt.figure()
    fig.suptitle('(g) Fig 2 : L2 norm of weights as function of $\lambda$', fontsize=14, fontweight='bold')

    ax = fig.add_subplot(111)
    ax.set_xlabel('$Log_{10}(\lambda)$')
    ax.set_ylabel('L2 norm of weights')
    plt.plot(np.log(1. / inv_lambdas), l2_norm, color='blue')
    #handles, labels = ax.get_legend_handles_labels()
    #ax.legend(handles, labels)
    plt.show()

    #Fig3 : L2 norm of weights for set of basis functions for each value of sigma

    fig = plt.figure()
    fig.suptitle('(g) Fig 3 : L2 norm of weights per sigma as function of $\lambda$', fontsize=14, fontweight='bold')

    ax = fig.add_subplot(111)
    ax.set_xlabel('$Log_{10}(\lambda)$')
    ax.set_ylabel('L2 norm of weights')
    l2 = np.asarray(l2)
    #lbl =  (1./inv_lambdas)
    lbl = ['$\sigma = 0$', '$\sigma = 0.1$', '$\sigma = 1$', '$\sigma = 10$', '$\sigma = 100$', '$\sigma = 1000$',
           '$\sigma = 10000$']
    for i in range(l2.shape[0]):
    #i = 0
        plt.plot(np.log10(1./inv_lambdas), l2[i,:], label = lbl[i])

    handles, labels = ax.get_legend_handles_labels()
    ax.legend(handles, labels)
    plt.show()

    #2.(b)
    degree = 3
    K = computeKernel(data, degree)
    print K.shape

    kernelizedLogisticRegression(K, y)


if __name__ == '__main__':
    main()