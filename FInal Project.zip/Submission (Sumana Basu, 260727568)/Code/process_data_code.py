import os
import nibabel as nib
import fnmatch
import scipy.misc
import cPickle
#import matplotlib.pyplot as plt

fname = 'path.txt'

with open(fname) as f:
    folders = f.readlines()
    
#remove whitespace characters like `\n` at the end of each line
folders = [x.strip() for x in folders]
pkl_file = open("t1c_data.pkl", "wb")
Xs = []
for folder in folders:
    print folder
    for file in os.listdir(folder):
        #if fnmatch.fnmatch(file, '*gvf_ISPC*') or fnmatch.fnmatch(file, '*t1p_ISPC*') or fnmatch.fnmatch(file, '*t1c_ISPC*'):
        if fnmatch.fnmatch(file, '*t1c_ISPC*'):
            #print file

            img = nib.load(folder + '/' + file)
            numpy_img = img.get_data()
            ni = numpy_img[25,:,:]
            image = scipy.misc.imresize(ni, 0.25)
            Xs.append(image.reshape((1,64,64)))
cPickle.dump(Xs, pkl_file)
            
            #imgplot = plt.imshow(ni)
            
pkl_file.close()
